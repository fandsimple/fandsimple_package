#!/usr/bin/python
# -*- coding: utf-8 -*-


def f(a):
    print(a)

a = 5
f(a)
